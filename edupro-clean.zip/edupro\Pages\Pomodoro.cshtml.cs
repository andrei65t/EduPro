using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EduPro.Pages
{
	public class PomodoroModel : PageModel
	{
		public void OnGet()
		{
		}
	}
}
